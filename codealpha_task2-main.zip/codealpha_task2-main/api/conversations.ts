import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getPool } from "./_db";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const pool = getPool();

  if (req.method === "GET") {
    const { rows } = await pool.query<{
      id: number;
      title: string;
      category: string | null;
      created_at: Date;
      updated_at: Date;
      message_count: number;
    }>(`
      SELECT c.id, c.title, c.category, c.created_at, c.updated_at,
             CAST(COUNT(m.id) AS INT) AS message_count
      FROM conversations c
      LEFT JOIN messages m ON m.conversation_id = c.id
      GROUP BY c.id
      ORDER BY c.updated_at DESC
    `);

    return res.json(
      rows.map((r) => ({
        id: r.id,
        title: r.title,
        category: r.category,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
        messageCount: r.message_count,
      }))
    );
  }

  if (req.method === "POST") {
    const { title, category } = req.body ?? {};
    if (!title || typeof title !== "string") {
      return res.status(400).json({ error: "Invalid request body" });
    }

    const { rows } = await pool.query<{
      id: number;
      title: string;
      category: string | null;
      created_at: Date;
      updated_at: Date;
    }>(
      `INSERT INTO conversations (title, category) VALUES ($1, $2)
       RETURNING id, title, category, created_at, updated_at`,
      [title, category ?? null]
    );

    const c = rows[0];
    return res.status(201).json({
      id: c.id,
      title: c.title,
      category: c.category,
      createdAt: c.created_at,
      updatedAt: c.updated_at,
      messageCount: 0,
    });
  }

  return res.status(405).json({ error: "Method not allowed" });
}
