import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getPool } from "../../_db";
import { callLyzr, inferConfidence } from "../../_lyzr";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const pool = getPool();
  const id = Number(req.query.id);

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ error: "Invalid id" });
  }

  const { message, category } = req.body ?? {};
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "Invalid request body" });
  }

  const { rows } = await pool.query(
    `SELECT id FROM conversations WHERE id = $1`,
    [id]
  );
  if (!rows[0]) {
    return res.status(404).json({ error: "Conversation not found" });
  }

  // Save user message
  await pool.query(
    `INSERT INTO messages (conversation_id, role, content, confidence) VALUES ($1, 'user', $2, NULL)`,
    [id, message]
  );

  // Call Lyzr AI
  let aiResponse: string;
  let confidence: "high" | "medium" | "low";
  try {
    aiResponse = await callLyzr(message);
    confidence = inferConfidence(aiResponse);
  } catch (err) {
    console.error("Lyzr API error:", err);
    return res.status(500).json({ error: "Failed to get AI response" });
  }

  // Save AI response
  await pool.query(
    `INSERT INTO messages (conversation_id, role, content, confidence) VALUES ($1, 'assistant', $2, $3)`,
    [id, aiResponse, confidence]
  );

  // Bump updatedAt
  await pool.query(
    `UPDATE conversations SET updated_at = NOW() WHERE id = $1`,
    [id]
  );

  return res.status(201).json({
    response: aiResponse,
    confidence,
    category: category ?? null,
  });
}
