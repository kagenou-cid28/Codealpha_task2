import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getPool } from "../../_db";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "PATCH") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const pool = getPool();
  const id = Number(req.query.id);

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ error: "Invalid id" });
  }

  const { title } = req.body ?? {};
  if (!title || typeof title !== "string") {
    return res.status(400).json({ error: "Invalid request body" });
  }

  const { rows } = await pool.query<{
    id: number;
    title: string;
    category: string | null;
    created_at: Date;
    updated_at: Date;
  }>(
    `UPDATE conversations SET title = $1, updated_at = NOW()
     WHERE id = $2
     RETURNING id, title, category, created_at, updated_at`,
    [title, id]
  );

  if (!rows[0]) {
    return res.status(404).json({ error: "Conversation not found" });
  }

  const c = rows[0];
  return res.json({
    id: c.id,
    title: c.title,
    category: c.category,
    createdAt: c.created_at,
    updatedAt: c.updated_at,
    messageCount: 0,
  });
}
