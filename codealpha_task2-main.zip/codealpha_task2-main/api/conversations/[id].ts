import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getPool } from "../_db";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const pool = getPool();
  const id = Number(req.query.id);

  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ error: "Invalid id" });
  }

  if (req.method === "GET") {
    const { rows: convRows } = await pool.query<{
      id: number;
      title: string;
      category: string | null;
      created_at: Date;
      updated_at: Date;
    }>(
      `SELECT id, title, category, created_at, updated_at FROM conversations WHERE id = $1`,
      [id]
    );

    if (!convRows[0]) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    const { rows: msgRows } = await pool.query<{
      id: number;
      conversation_id: number;
      role: string;
      content: string;
      confidence: string | null;
      created_at: Date;
    }>(
      `SELECT id, conversation_id, role, content, confidence, created_at
       FROM messages WHERE conversation_id = $1 ORDER BY created_at ASC`,
      [id]
    );

    const c = convRows[0];
    return res.json({
      id: c.id,
      title: c.title,
      category: c.category,
      createdAt: c.created_at,
      updatedAt: c.updated_at,
      messages: msgRows.map((m) => ({
        id: m.id,
        conversationId: m.conversation_id,
        role: m.role,
        content: m.content,
        confidence: m.confidence,
        createdAt: m.created_at,
      })),
    });
  }

  if (req.method === "DELETE") {
    await pool.query(`DELETE FROM conversations WHERE id = $1`, [id]);
    return res.status(204).send("");
  }

  return res.status(405).json({ error: "Method not allowed" });
}
