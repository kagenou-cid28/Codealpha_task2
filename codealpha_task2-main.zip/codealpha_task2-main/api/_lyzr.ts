export function inferConfidence(response: string): "high" | "medium" | "low" {
  const len = response.length;
  if (len > 400) return "high";
  if (len > 150) return "medium";
  return "low";
}

export async function callLyzr(message: string): Promise<string> {
  const LYZR_API_URL = process.env.LYZR_API_URL ?? "https://agent-prod.studio.lyzr.ai/v3/inference/chat/";
  const res = await fetch(LYZR_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.LYZR_API_KEY ?? "",
    },
    body: JSON.stringify({
      user_id: process.env.LYZR_USER_ID ?? "",
      agent_id: process.env.LYZR_AGENT_ID ?? "",
      session_id: process.env.LYZR_SESSION_ID ?? "",
      message,
    }),
  });

  if (!res.ok) {
    throw new Error(`Lyzr API error: ${res.status} ${res.statusText}`);
  }

  const data = await res.json() as { response?: string; message?: string; output?: string };
  return String(data.response ?? data.message ?? data.output ?? JSON.stringify(data));
}
