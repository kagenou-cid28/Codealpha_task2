import type { VercelRequest, VercelResponse } from "@vercel/node";
import { callLyzr, inferConfidence } from "./_lyzr";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { message, category } = req.body ?? {};
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "Invalid request body" });
  }

  try {
    const aiResponse = await callLyzr(message);
    const confidence = inferConfidence(aiResponse);
    return res.json({ response: aiResponse, confidence, category: category ?? null });
  } catch (err) {
    console.error("Lyzr API error:", err);
    return res.status(500).json({ error: "Failed to get AI response" });
  }
}
