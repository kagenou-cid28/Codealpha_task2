-- PathFinder AI — database bootstrap
-- Run this once against your Postgres database before deploying.
-- Compatible with Neon, Supabase, Railway, and any standard Postgres provider.

CREATE TABLE IF NOT EXISTS conversations (
  id          SERIAL PRIMARY KEY,
  title       TEXT NOT NULL,
  category    TEXT,
  created_at  TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS messages (
  id               SERIAL PRIMARY KEY,
  conversation_id  INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role             TEXT NOT NULL,
  content          TEXT NOT NULL,
  confidence       TEXT,
  created_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS messages_conversation_id_idx ON messages(conversation_id);
