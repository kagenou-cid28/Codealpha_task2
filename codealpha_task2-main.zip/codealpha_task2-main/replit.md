# PathFinder AI

An AI-powered Career & Placement Intelligence Platform. Ask questions about resumes, internships, placements, LinkedIn, interview prep, and career growth. Powered by Lyzr AI agents.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/pathfinder-ai run dev` — run the frontend (Replit manages this via workflows)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19 + Vite 7 + Tailwind CSS v4 + wouter
- API (Replit): Express 5
- API (Vercel): Serverless functions in `/api/`
- DB: PostgreSQL + Drizzle ORM
- AI: Lyzr AI agent (via REST API)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)

## Where things live

- `artifacts/pathfinder-ai/` — React + Vite frontend
- `artifacts/api-server/` — Express API server (for Replit / self-hosted)
- `api/` — Vercel serverless functions (mirrors Express routes; used when deployed via GitHub → Vercel)
- `lib/db/` — Drizzle ORM schema + database client
- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for API contract)
- `lib/api-client-react/` — Orval-generated React Query hooks
- `lib/api-zod/` — Orval-generated Zod schemas
- `migrations.sql` — SQL to bootstrap the database on a fresh Postgres instance

## Deploying to Vercel via GitHub

1. Push repo to GitHub
2. Import the GitHub repo in Vercel
3. Vercel auto-detects `vercel.json` — no framework settings needed
4. Add these environment variables in Vercel → Settings → Environment Variables:
   - `DATABASE_URL` — connection string to your cloud Postgres (Neon, Supabase, Railway, etc.)
   - `LYZR_API_KEY`
   - `LYZR_USER_ID`
   - `LYZR_AGENT_ID`
   - `LYZR_SESSION_ID`
   - `LYZR_API_URL` (optional, defaults to Lyzr's production URL)
5. Run `migrations.sql` once against your Postgres database to create the tables
6. Deploy — Vercel builds the frontend and serves the `/api/*` serverless routes

## Architecture decisions

- **Dual backend:** Express server for Replit dev/deploy; identical Vercel serverless functions in `/api/` for GitHub → Vercel. Same logic, same endpoints, no duplication of the frontend or database schema.
- **Optimistic rendering:** User messages appear immediately on send; AI response arrives asynchronously and replaces the optimistic state once the query refetches.
- **Module-level `_pending` handoff:** When a new chat is created, the component navigates before the AI call finishes. A module-level object carries the optimistic message + typing state to the newly mounted chat component.
- **Contract-first API:** `lib/api-spec/openapi.yaml` is the source of truth; React Query hooks and Zod schemas are generated from it via Orval.

## Product

- Welcome screen with quick-start prompt cards (Resume, LinkedIn, Placement, etc.)
- Persistent chat history in the sidebar
- Markdown-rendered AI responses with confidence badges (High / Medium / Low)
- Dark mode toggle
- Career path navigation links in sidebar
- Instant message rendering with animated typing indicator

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- `vite.config.ts` reads `PORT` and `BASE_PATH` from the environment. On Replit these are injected by the workflow; on Vercel/CI they fall back to safe defaults (`5173` and `/`).
- Replit-specific Vite plugins (`@replit/vite-plugin-*`) are only loaded when `REPL_ID` is set.
- The `api/` serverless functions use `pg` directly (not drizzle) to avoid pnpm workspace resolution complexity on Vercel. The Express routes use drizzle for consistency with the rest of the codebase.
- Always run `migrations.sql` before first deploy to a fresh Postgres instance.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
