import { Router } from "express";
import { SendMessageBody, AddMessageBody, AddMessageParams, GetConversationParams, DeleteConversationParams, UpdateConversationTitleParams, UpdateConversationTitleBody, CreateConversationBody } from "@workspace/api-zod";
import { db, conversationsTable, messagesTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";

const router = Router();

const LYZR_API_URL = process.env.LYZR_API_URL ?? "https://agent-prod.studio.lyzr.ai/v3/inference/chat/";
const LYZR_API_KEY = process.env.LYZR_API_KEY ?? "";
const LYZR_USER_ID = process.env.LYZR_USER_ID ?? "";
const LYZR_AGENT_ID = process.env.LYZR_AGENT_ID ?? "";
const LYZR_SESSION_ID = process.env.LYZR_SESSION_ID ?? "";

function inferConfidence(response: string): "high" | "medium" | "low" {
  const len = response.length;
  if (len > 400) return "high";
  if (len > 150) return "medium";
  return "low";
}

async function callLyzr(message: string): Promise<string> {
  const res = await fetch(LYZR_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": LYZR_API_KEY,
    },
    body: JSON.stringify({
      user_id: LYZR_USER_ID,
      agent_id: LYZR_AGENT_ID,
      session_id: LYZR_SESSION_ID,
      message,
    }),
  });

  if (!res.ok) {
    throw new Error(`Lyzr API error: ${res.status} ${res.statusText}`);
  }

  const data = await res.json() as { response?: string; message?: string; output?: string; [key: string]: unknown };
  const text = data.response ?? data.message ?? data.output ?? JSON.stringify(data);
  return String(text);
}

// POST /api/chat — stateless chat (no conversation saved)
router.post("/chat", async (req, res) => {
  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { message } = parsed.data;
  try {
    const aiResponse = await callLyzr(message);
    const confidence = inferConfidence(aiResponse);
    res.json({ response: aiResponse, confidence, category: parsed.data.category ?? null });
  } catch (err) {
    req.log.error({ err }, "Lyzr API error");
    res.status(500).json({ error: "Failed to get AI response" });
  }
});

// GET /api/conversations — list all conversations
router.get("/conversations", async (req, res) => {
  const rows = await db
    .select({
      id: conversationsTable.id,
      title: conversationsTable.title,
      category: conversationsTable.category,
      createdAt: conversationsTable.createdAt,
      updatedAt: conversationsTable.updatedAt,
      messageCount: sql<number>`cast(count(${messagesTable.id}) as int)`,
    })
    .from(conversationsTable)
    .leftJoin(messagesTable, eq(messagesTable.conversationId, conversationsTable.id))
    .groupBy(conversationsTable.id)
    .orderBy(desc(conversationsTable.updatedAt));

  res.json(rows);
});

// POST /api/conversations — create a new conversation
router.post("/conversations", async (req, res) => {
  const parsed = CreateConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const [convo] = await db
    .insert(conversationsTable)
    .values({ title: parsed.data.title, category: parsed.data.category ?? null })
    .returning();

  res.status(201).json({ ...convo, messageCount: 0 });
});

// GET /api/conversations/:id — get conversation with messages
router.get("/conversations/:id", async (req, res) => {
  const params = GetConversationParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const [convo] = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.id, params.data.id));

  if (!convo) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const msgs = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, params.data.id))
    .orderBy(messagesTable.createdAt);

  res.json({ ...convo, messages: msgs });
});

// DELETE /api/conversations/:id
router.delete("/conversations/:id", async (req, res) => {
  const params = DeleteConversationParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  await db.delete(conversationsTable).where(eq(conversationsTable.id, params.data.id));
  res.status(204).send();
});

// POST /api/conversations/:id/messages — add message + get AI response
router.post("/conversations/:id/messages", async (req, res) => {
  const params = AddMessageParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const parsed = AddMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const [convo] = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.id, params.data.id));

  if (!convo) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  // Save user message
  await db.insert(messagesTable).values({
    conversationId: params.data.id,
    role: "user",
    content: parsed.data.message,
    confidence: null,
  });

  // Get AI response
  let aiResponse: string;
  let confidence: "high" | "medium" | "low";
  try {
    aiResponse = await callLyzr(parsed.data.message);
    confidence = inferConfidence(aiResponse);
  } catch (err) {
    req.log.error({ err }, "Lyzr API error");
    res.status(500).json({ error: "Failed to get AI response" });
    return;
  }

  // Save AI message
  await db.insert(messagesTable).values({
    conversationId: params.data.id,
    role: "assistant",
    content: aiResponse,
    confidence,
  });

  // Update conversation updatedAt
  await db
    .update(conversationsTable)
    .set({ updatedAt: new Date() })
    .where(eq(conversationsTable.id, params.data.id));

  res.status(201).json({ response: aiResponse, confidence, category: parsed.data.category ?? null });
});

// PATCH /api/conversations/:id/title
router.patch("/conversations/:id/title", async (req, res) => {
  const params = UpdateConversationTitleParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const parsed = UpdateConversationTitleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const [updated] = await db
    .update(conversationsTable)
    .set({ title: parsed.data.title, updatedAt: new Date() })
    .where(eq(conversationsTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  res.json({ ...updated, messageCount: 0 });
});

export default router;
