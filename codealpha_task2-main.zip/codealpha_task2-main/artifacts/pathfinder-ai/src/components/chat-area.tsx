import { useEffect, useRef, useState } from "react";
import { useAddMessage, useCreateConversation, useGetConversation, getGetConversationQueryKey, getListConversationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Send, Menu, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { MarkdownRenderer } from "@/lib/markdown";

const PROMPT_CARDS = [
  "Improve my resume",
  "Create an AI Engineer roadmap",
  "Prepare for placements",
  "Review my LinkedIn profile",
  "Find internship opportunities",
];

// ─── Module-level handoff ─────────────────────────────────────────────────────
// When the user sends from the welcome screen we navigate immediately and the
// OLD component instance is replaced. This object lets the new instance pick up
// the optimistic message + typing state without any round-trip.
interface PendingState {
  message: string;
  chatId: number;
  done: boolean;
  onDone?: () => void;
}
let _pending: PendingState | null = null;

// ─── Types ────────────────────────────────────────────────────────────────────
type OptimisticMessage = {
  id: number;
  role: "user";
  content: string;
  confidence: null;
  createdAt: string;
};

// ─── Confidence badge ─────────────────────────────────────────────────────────
function ConfidenceBadge({ confidence }: { confidence?: "high" | "medium" | "low" | null }) {
  if (!confidence) return null;
  const styles = {
    high: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 border-green-200",
    medium: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200",
    low: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 border-red-200",
  };
  const labels = { high: "High Confidence", medium: "Medium Confidence", low: "Low Confidence" };
  return (
    <div className={cn("text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full border mb-2 w-fit", styles[confidence])}>
      {labels[confidence]}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export function ChatArea({ onOpenSidebar, chatId }: { onOpenSidebar: () => void; chatId?: number }) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const scrollRef = useRef<HTMLDivElement>(null);
  const preSubmitCountRef = useRef<number>(0);

  const [input, setInput] = useState("");

  // Initialise from module-level handoff if this component just mounted because
  // we navigated away from the welcome screen mid-flight.
  const [optimisticMsg, setOptimisticMsg] = useState<OptimisticMessage | null>(() => {
    if (_pending && chatId && _pending.chatId === chatId && !_pending.done) {
      return {
        id: Date.now(),
        role: "user",
        content: _pending.message,
        confidence: null,
        createdAt: new Date().toISOString(),
      };
    }
    return null;
  });

  const [isTyping, setIsTyping] = useState<boolean>(() => {
    return !!(chatId && _pending?.chatId === chatId && !_pending.done);
  });

  const createConversation = useCreateConversation();
  const addMessage = useAddMessage();

  const { data: conversation, isLoading } = useGetConversation(chatId ?? 0, {
    query: {
      enabled: !!chatId,
      queryKey: getGetConversationQueryKey(chatId ?? 0),
    },
  });

  // ── Wire up the module-level handoff callback ──────────────────────────────
  // When this component is newly mounted for a just-created chat, register a
  // callback so the background addMessage call can flip our local typing state.
  useEffect(() => {
    if (!_pending || _pending.chatId !== chatId) return;

    if (_pending.done) {
      setIsTyping(false);
      setOptimisticMsg(null);
      _pending = null;
      return;
    }

    _pending.onDone = () => {
      setIsTyping(false);
      setOptimisticMsg(null);
      _pending = null;
    };

    return () => {
      if (_pending) _pending.onDone = undefined;
    };
  }, [chatId]);

  // ── Clear optimistic message once real messages from server arrive ──────────
  useEffect(() => {
    if (optimisticMsg && (conversation?.messages?.length ?? 0) > preSubmitCountRef.current) {
      setOptimisticMsg(null);
    }
  }, [conversation?.messages?.length, optimisticMsg]);

  // ── Auto-scroll ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation?.messages, optimisticMsg, isTyping]);

  // ── Submit handler ─────────────────────────────────────────────────────────
  const handleSubmit = async (messageText: string) => {
    if (!messageText.trim() || isTyping) return;
    const text = messageText.trim();
    setInput("");

    if (!chatId) {
      // ── New conversation ──────────────────────────────────────────────────
      let newChatId: number;
      try {
        const title = text.length > 40 ? text.substring(0, 40) + "..." : text;
        const newConv = await createConversation.mutateAsync({ data: { title } });
        newChatId = newConv.id;
      } catch (err) {
        console.error("Failed to create conversation:", err);
        return;
      }

      // Set up handoff state so the new component instance picks it up.
      _pending = { message: text, chatId: newChatId, done: false };

      // ► Navigate immediately — user lands on the chat page right away ◄
      setLocation(`/chat/${newChatId}`);
      queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });

      // Fire AI call in background; update the handoff state when done.
      addMessage
        .mutateAsync({ id: newChatId, data: { message: text } })
        .then(() => {
          if (_pending?.chatId === newChatId) {
            _pending.done = true;
            _pending.onDone?.();
          }
          queryClient.invalidateQueries({ queryKey: getGetConversationQueryKey(newChatId) });
          queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        })
        .catch((err) => {
          console.error("AI call failed:", err);
          if (_pending?.chatId === newChatId) {
            _pending.done = true;
            _pending.onDone?.();
          }
        });

    } else {
      // ── Existing conversation ─────────────────────────────────────────────
      const optimistic: OptimisticMessage = {
        id: Date.now(),
        role: "user",
        content: text,
        confidence: null,
        createdAt: new Date().toISOString(),
      };
      preSubmitCountRef.current = conversation?.messages?.length ?? 0;
      setOptimisticMsg(optimistic);
      setIsTyping(true);

      try {
        await addMessage.mutateAsync({ id: chatId, data: { message: text } });
        await queryClient.invalidateQueries({ queryKey: getGetConversationQueryKey(chatId) });
        await queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      } catch (err) {
        console.error("Failed to send message:", err);
        setOptimisticMsg(null);
      } finally {
        setIsTyping(false);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit(input);
    }
  };

  // ── Merged messages (real + optimistic) ───────────────────────────────────
  const realMessages = conversation?.messages ?? [];
  const lastRealContent = realMessages[realMessages.length - 1]?.content;
  const showOptimistic = optimisticMsg && optimisticMsg.content !== lastRealContent;
  const displayMessages = showOptimistic ? [...realMessages, optimisticMsg] : realMessages;

  // ─────────────────────────────────────────────────────────────────────────────
  const renderWelcome = () => (
    <div className="flex-1 flex flex-col items-center justify-center p-6 text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6 shadow-sm">
        <Bot size={32} />
      </div>
      <h1 className="text-3xl font-bold text-foreground mb-3">
        Your Personal Career Intelligence Assistant
      </h1>
      <p className="text-muted-foreground max-w-xl mb-12 text-lg">
        Get guidance on placements, internships, resumes, interviews, LinkedIn, and career growth.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-3xl w-full">
        {PROMPT_CARDS.map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleSubmit(prompt)}
            className="p-4 rounded-xl border bg-card text-card-foreground shadow-sm hover:shadow-md hover:border-primary/50 transition-all text-left text-sm font-medium hover:-translate-y-1"
          >
            {prompt}
          </button>
        ))}
      </div>
    </div>
  );

  const renderChat = () => (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6" ref={scrollRef}>
      {displayMessages.map((msg, idx) => (
        <div
          key={msg.id ?? idx}
          className={cn(
            "flex w-full animate-in fade-in slide-in-from-bottom-2 duration-300",
            msg.role === "user" ? "justify-end" : "justify-start"
          )}
        >
          <div
            className={cn(
              "max-w-[85%] md:max-w-[75%] rounded-2xl px-5 py-4 shadow-sm",
              msg.role === "user"
                ? "bg-primary text-primary-foreground rounded-tr-sm"
                : "bg-card border text-card-foreground rounded-tl-sm"
            )}
          >
            {msg.role === "assistant" && <ConfidenceBadge confidence={msg.confidence} />}
            <MarkdownRenderer content={msg.content} />
          </div>
        </div>
      ))}

      {isTyping && (
        <div className="flex w-full justify-start animate-in fade-in">
          <div className="bg-card border text-card-foreground rounded-2xl rounded-tl-sm px-5 py-4 shadow-sm flex items-center gap-2">
            <div className="flex space-x-1">
              {[0, 150, 300].map((delay) => (
                <div
                  key={delay}
                  className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce"
                  style={{ animationDelay: `${delay}ms` }}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="flex-1 flex flex-col h-[100dvh] bg-background">
      {/* Mobile header */}
      <div className="md:hidden flex items-center p-4 border-b bg-background z-10 sticky top-0">
        <Button variant="ghost" size="icon" onClick={onOpenSidebar} className="mr-2">
          <Menu className="h-5 w-5" />
        </Button>
        <div className="font-semibold text-foreground">PathFinder AI</div>
      </div>

      {chatId && !conversation && isLoading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      ) : !chatId ? (
        renderWelcome()
      ) : (
        renderChat()
      )}

      {/* Input */}
      <div className="p-4 bg-background border-t">
        <div className="max-w-3xl mx-auto relative flex items-end gap-2 bg-card rounded-xl border shadow-sm p-2 focus-within:ring-1 focus-within:ring-primary/50 transition-all">
          <Textarea
            placeholder="Ask anything about your career..."
            className="min-h-[44px] max-h-32 resize-none border-0 focus-visible:ring-0 shadow-none bg-transparent py-3"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isTyping}
            rows={1}
            autoFocus
          />
          <Button
            size="icon"
            className="h-10 w-10 shrink-0 rounded-lg mb-1"
            disabled={!input.trim() || isTyping}
            onClick={() => handleSubmit(input)}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <div className="text-center mt-2 text-[10px] text-muted-foreground">
          Press{" "}
          <kbd className="px-1 py-0.5 rounded bg-muted border font-mono text-[9px]">Cmd</kbd> +{" "}
          <kbd className="px-1 py-0.5 rounded bg-muted border font-mono text-[9px]">Enter</kbd>{" "}
          to send
        </div>
      </div>
    </div>
  );
}
