import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { 
  Plus, 
  MessageSquare, 
  Trash2, 
  Settings, 
  Sun, 
  Moon, 
  Menu, 
  FileText, 
  Briefcase, 
  Cpu, 
  Code, 
  GraduationCap, 
  Linkedin, 
  Users 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useTheme } from "@/components/theme-provider";
import { useListConversations, useDeleteConversation, getListConversationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

const QUICK_LINKS = [
  { name: "Resume Review", icon: FileText, category: "resume" },
  { name: "Placement Prep", icon: Briefcase, category: "placement" },
  { name: "AI Careers", icon: Cpu, category: "ai" },
  { name: "Software Careers", icon: Code, category: "software" },
  { name: "Internship Guidance", icon: GraduationCap, category: "internship" },
  { name: "LinkedIn Tips", icon: Linkedin, category: "linkedin" },
  { name: "Interview Prep", icon: Users, category: "interview" },
];

export function Sidebar({ isOpen, setIsOpen, currentChatId }: { isOpen: boolean; setIsOpen: (open: boolean) => void; currentChatId?: number }) {
  const [, setLocation] = useLocation();
  const { theme, setTheme } = useTheme();
  const queryClient = useQueryClient();
  
  const { data: conversations, isLoading } = useListConversations();
  const deleteConversation = useDeleteConversation();

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    deleteConversation.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        if (currentChatId === id) {
          setLocation("/");
        }
      }
    });
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}
      
      <div className={cn(
        "fixed md:static inset-y-0 left-0 z-50 w-72 bg-sidebar border-r border-sidebar-border flex flex-col transition-transform duration-300 ease-in-out md:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Header */}
        <div className="p-4 flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => setLocation("/")}
          >
            <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground font-bold">
              PF
            </div>
            <span className="font-semibold text-sidebar-foreground text-lg tracking-tight">PathFinder AI</span>
          </div>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsOpen(false)}>
            <Menu className="h-5 w-5" />
          </Button>
        </div>

        {/* New Chat Button */}
        <div className="px-4 pb-4">
          <Button 
            className="w-full justify-start gap-2 bg-primary text-primary-foreground hover:bg-accent-hover shadow-sm"
            onClick={() => {
              setLocation("/");
              setIsOpen(false);
            }}
          >
            <Plus className="h-4 w-4" />
            New Chat
          </Button>
        </div>

        <ScrollArea className="flex-1 px-4">
          {/* Recent Chats */}
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">
              Recent Conversations
            </h3>
            
            <div className="space-y-1">
              {isLoading ? (
                Array(3).fill(0).map((_, i) => (
                  <div key={i} className="h-10 bg-muted animate-pulse rounded-md" />
                ))
              ) : conversations?.length === 0 ? (
                <p className="text-sm text-muted-foreground px-2">No recent chats</p>
              ) : (
                conversations?.map(conv => (
                  <div 
                    key={conv.id}
                    onClick={() => {
                      setLocation(`/chat/${conv.id}`);
                      setIsOpen(false);
                    }}
                    className={cn(
                      "group flex items-center justify-between p-2 rounded-md cursor-pointer hover:bg-sidebar-accent transition-colors",
                      currentChatId === conv.id && "bg-sidebar-accent"
                    )}
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <MessageSquare className="h-4 w-4 shrink-0 text-muted-foreground" />
                      <div className="flex flex-col overflow-hidden">
                        <span className="text-sm truncate text-sidebar-foreground">{conv.title}</span>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 opacity-0 group-hover:opacity-100 shrink-0 text-muted-foreground hover:text-destructive"
                      onClick={(e) => handleDelete(e, conv.id)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Quick Links */}
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">
              Career Paths
            </h3>
            <div className="space-y-1">
              {QUICK_LINKS.map(link => (
                <div 
                  key={link.name}
                  className="flex items-center gap-3 p-2 rounded-md cursor-pointer hover:bg-sidebar-accent text-sidebar-foreground transition-colors text-sm"
                  onClick={() => {
                    // Logic to start chat with category
                    setLocation("/");
                    setIsOpen(false);
                  }}
                >
                  <link.icon className="h-4 w-4 text-muted-foreground" />
                  {link.name}
                </div>
              ))}
            </div>
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-sidebar-border space-y-2">
          <div 
            className="flex items-center gap-3 p-2 rounded-md cursor-pointer hover:bg-sidebar-accent text-sidebar-foreground transition-colors text-sm"
            onClick={() => setLocation("/settings")}
          >
            <Settings className="h-4 w-4 text-muted-foreground" />
            Settings
          </div>
          <div 
            className="flex items-center gap-3 p-2 rounded-md cursor-pointer hover:bg-sidebar-accent text-sidebar-foreground transition-colors text-sm"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4 text-muted-foreground" />
            ) : (
              <Moon className="h-4 w-4 text-muted-foreground" />
            )}
            {theme === "dark" ? "Light Mode" : "Dark Mode"}
          </div>
        </div>
      </div>
    </>
  );
}