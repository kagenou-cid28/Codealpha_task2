import React from "react";

export function MarkdownRenderer({ content }: { content: string }) {
  // Simple markdown renderer handling bold, italic, code blocks, lists and paragraphs
  
  const processText = (text: string) => {
    // Bold
    let html = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Italic
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
    // Inline code
    html = html.replace(/`(.*?)`/g, '<code class="bg-muted px-1.5 py-0.5 rounded-md text-sm">$1</code>');
    return html;
  };

  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let currentList: React.ReactNode[] = [];
  let isCodeBlock = false;
  let codeBlockContent = '';

  lines.forEach((line, index) => {
    // Code block
    if (line.startsWith('```')) {
      if (isCodeBlock) {
        elements.push(
          <pre key={`code-${index}`} className="bg-muted p-4 rounded-lg overflow-x-auto my-4 text-sm">
            <code>{codeBlockContent}</code>
          </pre>
        );
        isCodeBlock = false;
        codeBlockContent = '';
      } else {
        isCodeBlock = true;
      }
      return;
    }

    if (isCodeBlock) {
      codeBlockContent += line + '\n';
      return;
    }

    // Unordered List
    if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
      const text = processText(line.trim().substring(2));
      currentList.push(<li key={`li-${index}`} dangerouslySetInnerHTML={{ __html: text }} />);
      return;
    }

    // Numbered List
    if (/^\d+\.\s/.test(line.trim())) {
      const text = processText(line.trim().replace(/^\d+\.\s/, ''));
      currentList.push(<li key={`li-${index}`} dangerouslySetInnerHTML={{ __html: text }} />);
      return;
    }

    // Flush lists if empty line
    if (currentList.length > 0 && line.trim() === '') {
      elements.push(
        <ul key={`ul-${index}`} className="list-disc list-inside my-4 space-y-1 ml-4">
          {currentList}
        </ul>
      );
      currentList = [];
    }

    // Headings
    if (line.startsWith('### ')) {
      elements.push(<h3 key={`h3-${index}`} className="text-lg font-bold mt-6 mb-2">{line.substring(4)}</h3>);
      return;
    }
    if (line.startsWith('## ')) {
      elements.push(<h2 key={`h2-${index}`} className="text-xl font-bold mt-8 mb-3">{line.substring(3)}</h2>);
      return;
    }

    // Paragraph
    if (line.trim() !== '') {
      const text = processText(line);
      elements.push(<p key={`p-${index}`} className="my-2 leading-relaxed" dangerouslySetInnerHTML={{ __html: text }} />);
    }
  });

  // Flush remaining lists
  if (currentList.length > 0) {
    elements.push(
      <ul key="ul-end" className="list-disc list-inside my-4 space-y-1 ml-4">
        {currentList}
      </ul>
    );
  }

  return <div className="prose dark:prose-invert max-w-none text-foreground break-words">{elements}</div>;
}