import { useState } from "react";
import { Sidebar } from "@/components/sidebar";
import { ChatArea } from "@/components/chat-area";
import { useParams } from "wouter";

export default function ChatPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const params = useParams();
  const chatId = params.id ? parseInt(params.id, 10) : undefined;

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-background">
      <Sidebar 
        isOpen={sidebarOpen} 
        setIsOpen={setSidebarOpen} 
        currentChatId={chatId}
      />
      <ChatArea 
        onOpenSidebar={() => setSidebarOpen(true)} 
        chatId={chatId}
      />
    </div>
  );
}