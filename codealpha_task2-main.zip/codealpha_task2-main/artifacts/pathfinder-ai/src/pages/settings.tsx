import { useState } from "react";
import { Sidebar } from "@/components/sidebar";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SettingsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-background">
      <Sidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />
      
      <div className="flex-1 flex flex-col overflow-y-auto">
        <div className="md:hidden flex items-center p-4 border-b bg-background z-10 sticky top-0">
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)} className="mr-2">
            <Menu className="h-5 w-5" />
          </Button>
          <div className="font-semibold text-foreground">Settings</div>
        </div>

        <div className="p-6 md:p-12 max-w-4xl w-full mx-auto animate-in fade-in slide-in-from-bottom-4">
          <h1 className="text-3xl font-bold mb-8">Settings</h1>
          
          <div className="space-y-6">
            <div className="bg-card border rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Account Profile</h2>
              <p className="text-muted-foreground mb-4">Manage your personal information and career goals.</p>
              
              <div className="space-y-4 max-w-md">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Name</label>
                  <input type="text" className="w-full bg-background border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="Jane Doe" disabled />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Current Role</label>
                  <input type="text" className="w-full bg-background border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="Student" disabled />
                </div>
                <Button disabled>Save Changes</Button>
              </div>
            </div>

            <div className="bg-card border rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Preferences</h2>
              <p className="text-muted-foreground">App preferences are currently synchronized with your browser settings.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}